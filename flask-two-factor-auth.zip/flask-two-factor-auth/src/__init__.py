from decouple import config
from flask import Flask
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from flask_mail import Mail
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

from src.db import db  # ✅ Use from separate db.py file

bcrypt = Bcrypt()
mail = Mail()
login_manager = LoginManager()
migrate = Migrate()

def create_app():
    app = Flask(__name__)
    app.config.from_object(config("APP_SETTINGS"))

    # Initialize extensions
    bcrypt.init_app(app)
    db.init_app(app)
    migrate.init_app(app, db)
    mail.init_app(app)
    login_manager.init_app(app)

    # Set login view config
    login_manager.login_view = "accounts.login"
    login_manager.login_message_category = "danger"

    # Register blueprints
    from src.accounts.views import accounts_bp
    from src.core.views import core_bp
    from src.vault.views import vault_bp

    app.register_blueprint(accounts_bp)
    app.register_blueprint(core_bp)
    app.register_blueprint(vault_bp)

    # Import user model for user_loader
    from src.accounts.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    return app
