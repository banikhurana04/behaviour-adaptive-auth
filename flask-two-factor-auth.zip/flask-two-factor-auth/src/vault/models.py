from src.db import db

class PasswordEntry(db.Model):
    __tablename__ = 'password_entries'  # Optional but good for clarity

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)  # ✅ Fix table name
    app_name = db.Column(db.String(100), nullable=False)
    username = db.Column(db.String(100), nullable=False)
    password_encrypted = db.Column(db.LargeBinary, nullable=False)
