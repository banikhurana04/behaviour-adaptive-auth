from cryptography.fernet import Fernet
from flask import current_app

def encrypt_password(plain_password):
    key = current_app.config["ENCRYPTION_KEY"]
    fernet = Fernet(key.encode())
    return fernet.encrypt(plain_password.encode())

def decrypt_password(encrypted_password):
    key = current_app.config["ENCRYPTION_KEY"]
    fernet = Fernet(key.encode())
    return fernet.decrypt(encrypted_password).decode()
