from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from src.db import db
from .models import PasswordEntry
from .utils import encrypt_password, decrypt_password

vault_bp = Blueprint("vault", __name__, template_folder="templates")

@vault_bp.route('/vault', methods=['GET', 'POST'])
@login_required
def password_vault():
    if request.method == 'POST':
        app_name = request.form['app_name']
        username = request.form['username']
        password = request.form['password']

        encrypted_password = encrypt_password(password)

        entry = PasswordEntry(user_id=current_user.id, app_name=app_name,
                              username=username, password_encrypted=encrypted_password)
        db.session.add(entry)
        db.session.commit()
        flash('Password saved securely!', 'success')
        return redirect(url_for('vault.password_vault'))

    entries = PasswordEntry.query.filter_by(user_id=current_user.id).all()
    decrypted_entries = [
        {
            'app_name': e.app_name,
            'username': e.username,
            'password': decrypt_password(e.password_encrypted)
        } for e in entries
    ]
    return render_template("vault/vault_home.html", entries=decrypted_entries)
